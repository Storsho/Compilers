/*
 * Generic, conservative loop-invariant code-motion pass for the TAC format
 * emitted by loop.y.
 *
 * It identifies a loop of the form:
 *   Lstart:
 *   ... condition computation ...
 *   if ... goto Lbody
 *   goto Lexit
 *   Lbody:
 *   ... body ...
 *   goto Lstart
 *   Lexit:
 *
 * It hoists temporary-only arithmetic instructions when their operands are
 * not changed by the loop body. This is an educational optimizer, not a
 * production compiler optimizer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINES 10000
#define LINE_LEN 512
#define MAX_NAMES 10000

static char lines[MAX_LINES][LINE_LEN];
static int count;
static char names[MAX_NAMES][128];
static int name_count;

static int is_label(const char *s) {
    const char *colon = strchr(s, ':');
    if (!colon || strchr(s, '=') || strncmp(s, "if ", 3) == 0 ||
        strncmp(s, "goto ", 5) == 0) return 0;
    return colon == s + strlen(s) - 2 || colon == s + strlen(s) - 1;
}

static int is_identifier_char(int c) {
    return isalnum((unsigned char)c) || c == '_';
}

static void add_name(const char *s) {
    for (int i = 0; i < name_count; i++)
        if (strcmp(names[i], s) == 0) return;
    if (name_count < MAX_NAMES) {
        strncpy(names[name_count], s, sizeof(names[name_count]) - 1);
        names[name_count][sizeof(names[name_count]) - 1] = '\0';
        name_count++;
    }
}

static int has_name(const char *line, const char *name) {
    size_t n = strlen(name);
    const char *p = line;
    while ((p = strstr(p, name)) != NULL) {
        int left_ok = (p == line || !is_identifier_char((unsigned char)p[-1]));
        int right_ok = !is_identifier_char((unsigned char)p[n]);
        if (left_ok && right_ok) return 1;
        p += n;
    }
    return 0;
}

static int parse_arithmetic(const char *line, char *dest, char *a,
                            char *op, char *b) {
    char rhs[256];
    if (sscanf(line, " %127s = %255[^\n]", dest, rhs) != 2) return 0;
    char operator_char = 0;
    char *p = rhs;
    while (*p) {
        if ((*p == '+' || *p == '-' || *p == '*' || *p == '/') &&
            p != rhs) {
            operator_char = *p;
            *p = '\0';
            p++;
            while (isspace((unsigned char)*p)) p++;
            break;
        }
        p++;
    }
    if (!operator_char) return 0;
    char left[128], right[128];
    snprintf(left, sizeof(left), "%s", rhs);
    char *end = left + strlen(left) - 1;
    while (end >= left && isspace((unsigned char)*end)) *end-- = '\0';
    if (sscanf(left, "%127s", a) != 1 || sscanf(p, "%127s", right) != 1)
        return 0;
    strcpy(b, right);
    *op = operator_char;
    return 1;
}

static int is_temp(const char *s) {
    return s[0] == 't' && isdigit((unsigned char)s[1]);
}

int main(void) {
    FILE *in = fopen("tac.txt", "r");
    if (!in) { perror("tac.txt"); return 1; }
    while (count < MAX_LINES && fgets(lines[count], LINE_LEN, in)) count++;
    fclose(in);

    int start = -1, back = -1, body = -1, exit_label = -1;
    char start_name[128] = "", body_name[128] = "", exit_name[128] = "";

    /* Find a backward goto and its loop-start label. */
    for (int i = 0; i < count; i++) {
        char target[128];
        if (sscanf(lines[i], "goto %127s", target) == 1) {
            target[strcspn(target, "\r\n")] = '\0';
            for (int j = 0; j < i; j++) {
                char lab[128];
                if (sscanf(lines[j], " %127[^:]:", lab) == 1 &&
                    strcmp(lab, target) == 0) {
                    start = j; back = i;
                    strcpy(start_name, target);
                    break;
                }
            }
        }
    }

    if (start >= 0 && back > start) {
        /* Find body label after start and before back: first conditional target. */
        for (int i = start; i < back; i++) {
            char target[128];
            if (sscanf(lines[i], "if %*s %*s %*s goto %127s", target) == 1) {
                target[strcspn(target, "\r\n")] = '\0';
                strcpy(body_name, target);
                break;
            }
        }
        for (int i = start + 1; i < back; i++) {
            char lab[128];
            if (sscanf(lines[i], " %127[^:]:", lab) == 1 &&
                strcmp(lab, body_name) == 0) { body = i; break; }
        }
        /* The exit label is normally the next label after the back edge. */
        for (int i = back + 1; i < count; i++) {
            char lab[128];
            if (sscanf(lines[i], " %127[^:]:", lab) == 1) {
                exit_label = i;
                strcpy(exit_name, lab);
                break;
            }
        }
    }

    int moved[MAX_LINES] = {0};
    if (start >= 0 && body >= 0 && back >= 0) {
        /* Collect variables assigned in the loop body. */
        char modified[MAX_NAMES][128];
        int modified_count = 0;
        for (int i = body + 1; i < back; i++) {
            char dest[128];
            if (sscanf(lines[i], " %127s =", dest) == 1) {
                int seen = 0;
                for (int k = 0; k < modified_count; k++)
                    if (strcmp(modified[k], dest) == 0) seen = 1;
                if (!seen && modified_count < MAX_NAMES)
                    strcpy(modified[modified_count++], dest);
            }
        }

        /* Hoist arithmetic temp assignments in the body if operands are invariant. */
        for (int i = body + 1; i < back; i++) {
            char dest[128], a[128], b[128], op;
            if (!parse_arithmetic(lines[i], dest, a, &op, b) || !is_temp(dest))
                continue;
            int invariant = 1;
            for (int k = 0; k < modified_count; k++) {
                if (strcmp(a, modified[k]) == 0 || strcmp(b, modified[k]) == 0)
                    invariant = 0;
            }
            /* Also require operands that are temporaries to be defined outside the body
               or already selected for hoisting. */
            if (is_temp(a) || is_temp(b)) {
                int def_before = 0;
                for (int j = start; j < body; j++) {
                    char d[128];
                    if (sscanf(lines[j], " %127s =", d) == 1 &&
                        (strcmp(d, a) == 0 || strcmp(d, b) == 0)) def_before = 1;
                }
                if (!def_before) invariant = 0;
            }
            if (invariant) moved[i] = 1;
        }
    }

    FILE *out = fopen("optimized.txt", "w");
    if (!out) { perror("optimized.txt"); return 1; }

    /* Emit hoisted instructions before loop start, then original lines except moved ones. */
    if (start >= 0) {
        for (int i = 0; i < start; i++) fputs(lines[i], out);
        for (int i = 0; i < count; i++)
            if (moved[i]) fputs(lines[i], out);
        for (int i = start; i < count; i++)
            if (!moved[i]) fputs(lines[i], out);
    } else {
        /* No recognizable loop: preserve TAC unchanged. */
        for (int i = 0; i < count; i++) fputs(lines[i], out);
    }

    fclose(out);
    printf("Optimization pass completed. Output: optimized.txt\n");
    if (start < 0) printf("No loop back-edge recognized; TAC was preserved unchanged.\n");
    return 0;
}
