%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);

static FILE *tac;
static int temp_count = 0;
static int label_count = 0;

typedef struct {
    char start[32];
    char body[32];
    char end[32];
} LoopLabels;

static LoopLabels loops[100];
static int loop_depth = -1;

static char *new_temp(void) {
    char buf[32];
    snprintf(buf, sizeof(buf), "t%d", ++temp_count);
    return strdup(buf);
}

static void new_label(char *dst, size_t n) {
    snprintf(dst, n, "L%d", ++label_count);
}
%}

%union {
    char *str;
}

%token WHILE
%token LT LE GT GE EQ NE
%token ASSIGN PLUS MINUS MUL DIV
%token LPAREN RPAREN LBRACE RBRACE SEMI INVALID
%token <str> ID NUM

%type <str> expression condition

%left PLUS MINUS
%left MUL DIV
%right UMINUS

%start program

%%
program:
    statement_list
    ;

statement_list:
      /* empty */
    | statement_list statement
    ;

statement:
      assignment
    | while_statement
    | block
    ;

block:
    LBRACE statement_list RBRACE
    ;

assignment:
    ID ASSIGN expression SEMI
    {
        fprintf(tac, "%s = %s\n", $1, $3);
    }
    ;

while_statement:
    WHILE LPAREN
    {
        if (loop_depth >= 99) {
            yyerror("maximum loop nesting exceeded");
            YYABORT;
        }
        loop_depth++;
        new_label(loops[loop_depth].start, sizeof(loops[loop_depth].start));
        new_label(loops[loop_depth].body, sizeof(loops[loop_depth].body));
        new_label(loops[loop_depth].end, sizeof(loops[loop_depth].end));
        fprintf(tac, "%s:\n", loops[loop_depth].start);
    }
    condition RPAREN LBRACE
    {
        fprintf(tac, "%s:\n", loops[loop_depth].body);
    }
    statement_list RBRACE
    {
        fprintf(tac, "goto %s\n", loops[loop_depth].start);
        fprintf(tac, "%s:\n", loops[loop_depth].end);
        loop_depth--;
    }
    ;

condition:
    expression LT expression
    {
        fprintf(tac, "if %s < %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    | expression LE expression
    {
        fprintf(tac, "if %s <= %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    | expression GT expression
    {
        fprintf(tac, "if %s > %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    | expression GE expression
    {
        fprintf(tac, "if %s >= %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    | expression EQ expression
    {
        fprintf(tac, "if %s == %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    | expression NE expression
    {
        fprintf(tac, "if %s != %s goto %s\n", $1, $3, loops[loop_depth].body);
        fprintf(tac, "goto %s\n", loops[loop_depth].end);
        $$ = strdup("condition");
    }
    ;

expression:
      expression PLUS expression
    {
        char *t = new_temp();
        fprintf(tac, "%s = %s + %s\n", t, $1, $3);
        $$ = t;
    }
    | expression MINUS expression
    {
        char *t = new_temp();
        fprintf(tac, "%s = %s - %s\n", t, $1, $3);
        $$ = t;
    }
    | expression MUL expression
    {
        char *t = new_temp();
        fprintf(tac, "%s = %s * %s\n", t, $1, $3);
        $$ = t;
    }
    | expression DIV expression
    {
        char *t = new_temp();
        fprintf(tac, "%s = %s / %s\n", t, $1, $3);
        $$ = t;
    }
    | MINUS expression %prec UMINUS
    {
        char *t = new_temp();
        fprintf(tac, "%s = 0 - %s\n", t, $2);
        $$ = t;
    }
    | LPAREN expression RPAREN
    {
        $$ = $2;
    }
    | ID  { $$ = $1; }
    | NUM { $$ = $1; }
    ;

%%
void yyerror(const char *s) {
    fprintf(stderr, "Parser error: %s\n", s);
}

int main(void) {
    tac = fopen("tac.txt", "w");
    if (!tac) {
        perror("tac.txt");
        return 1;
    }
    int result = yyparse();
    fclose(tac);
    if (result == 0) {
        printf("Syntax is correct. TAC saved to tac.txt\n");
        return 0;
    }
    remove("tac.txt");
    return 1;
}
