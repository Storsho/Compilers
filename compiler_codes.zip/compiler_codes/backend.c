/*
 * Educational pseudo-assembly backend for the TAC emitted by loop.y.
 * Supports labels, goto, conditional branches, binary arithmetic,
 * unary-minus TAC (0 - x), and simple assignments.
 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

static int is_label_line(const char *line, char *label) {
    char *colon = strchr(line, ':');
    if (!colon || strchr(line, '=') || strncmp(line, "if ", 3) == 0 ||
        strncmp(line, "goto ", 5) == 0) return 0;
    while (*line && isspace((unsigned char)*line)) line++;
    size_t n = (size_t)(colon - line);
    if (n == 0 || n >= 128) return 0;
    strncpy(label, line, n);
    label[n] = '\0';
    return 1;
}

int main(void) {
    FILE *in = fopen("optimized.txt", "r");
    FILE *out = fopen("target.txt", "w");
    char line[512], dest[128], a[128], b[128], op, label[128];

    if (!in) { perror("optimized.txt"); return 1; }
    if (!out) { perror("target.txt"); fclose(in); return 1; }

    while (fgets(line, sizeof(line), in)) {
        if (line[0] == '\n' || line[0] == '\r') continue;

        if (is_label_line(line, label)) {
            fprintf(out, "%s:\n", label);
            continue;
        }

        if (sscanf(line, "goto %127s", label) == 1) {
            label[strcspn(label, "\r\n")] = '\0';
            fprintf(out, "JMP %s\n", label);
            continue;
        }

        /* Conditional branch: if a < b goto L1 (also <=, >, >=, ==, !=). */
        {
            char left[128], rel[8], right[128], target[128];
            if (sscanf(line, "if %127s %7s %127s goto %127s",
                       left, rel, right, target) == 4) {
                target[strcspn(target, "\r\n")] = '\0';
                fprintf(out, "LOAD R1, %s\n", left);
                fprintf(out, "LOAD R2, %s\n", right);
                fprintf(out, "CMP R1, R2\n");
                if (strcmp(rel, "<") == 0) fprintf(out, "JLT %s\n", target);
                else if (strcmp(rel, "<=") == 0) fprintf(out, "JLE %s\n", target);
                else if (strcmp(rel, ">") == 0) fprintf(out, "JGT %s\n", target);
                else if (strcmp(rel, ">=") == 0) fprintf(out, "JGE %s\n", target);
                else if (strcmp(rel, "==") == 0) fprintf(out, "JEQ %s\n", target);
                else if (strcmp(rel, "!=") == 0) fprintf(out, "JNE %s\n", target);
                continue;
            }
        }

        if (sscanf(line, " %127s = %127s %c %127s", dest, a, &op, b) == 4) {
            fprintf(out, "LOAD R1, %s\n", a);
            if (op == '+') fprintf(out, "ADD R1, %s\n", b);
            else if (op == '-') fprintf(out, "SUB R1, %s\n", b);
            else if (op == '*') fprintf(out, "MUL R1, %s\n", b);
            else if (op == '/') fprintf(out, "DIV R1, %s\n", b);
            else {
                fprintf(stderr, "Unsupported operator in: %s", line);
                continue;
            }
            fprintf(out, "STORE %s, R1\n", dest);
            continue;
        }

        if (sscanf(line, " %127s = %127s", dest, a) == 2) {
            fprintf(out, "LOAD R1, %s\n", a);
            fprintf(out, "STORE %s, R1\n", dest);
            continue;
        }

        fprintf(stderr, "Warning: could not translate TAC line: %s", line);
    }

    fclose(in);
    fclose(out);
    printf("Target code generated in target.txt\n");
    return 0;
}
