a = b;
c = a + 5;
d = a * c;
