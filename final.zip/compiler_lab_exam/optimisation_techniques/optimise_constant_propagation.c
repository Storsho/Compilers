/* (d) Code optimisation - Constant propagation
   After a statement  x = constant , later uses of x in the same block
   are replaced by the constant (until x is changed).
       a = 5                 a = 5
       t1 = a + 2    =>      t1 = 5 + 2
   (constant folding can then be applied to get t1 = 7)
   If x is a temporary that is no longer used, the statement is removed.
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

char tok[100][7][20];   /* each TAC line split into words */
int  nt[100];           /* number of words in the line */
int  del[100];          /* 1 = statement removed */
char code[100][100];
int  n = 0;

int istemp(char *s) { return s[0] == 't' && isdigit(s[1]); }

/* label, goto and if end a basic block */
int boundary(int i)
{
    return nt[i] == 1 || strcmp(tok[i][0], "goto") == 0 || strcmp(tok[i][0], "if") == 0;
}

/* variable assigned by line i, or "" */
char *defined(int i)
{
    if ((nt[i] == 3 || nt[i] == 5) && strcmp(tok[i][1], "=") == 0)
        return tok[i][0];
    return "";
}

/* replace operand s by r in line i, returns 1 if replaced */
int replace(int i, char *s, char *r)
{
    int pos[2], np = 0, done = 0;

    if (strcmp(tok[i][0], "if") == 0) { pos[0] = 1; pos[1] = 3; np = 2; }
    else if (nt[i] == 3)              { pos[0] = 2; np = 1; }
    else if (nt[i] == 5)              { pos[0] = 2; pos[1] = 4; np = 2; }

    for (int k = 0; k < np; k++)
        if (strcmp(tok[i][pos[k]], s) == 0) {
            strcpy(tok[i][pos[k]], r);
            done = 1;
        }
    return done;
}

int used(char *s)
{
    for (int k = 0; k < n; k++) {
        if (del[k]) continue;
        if (strcmp(tok[k][0], "if") == 0 && (strcmp(tok[k][1], s) == 0 || strcmp(tok[k][3], s) == 0))
            return 1;
        if ((nt[k] == 3 || nt[k] == 5) && strcmp(tok[k][2], s) == 0)
            return 1;
        if (nt[k] == 5 && strcmp(tok[k][4], s) == 0)
            return 1;
    }
    return 0;
}

void join(int i, char *buf)
{
    strcpy(buf, tok[i][0]);
    for (int k = 1; k < nt[i]; k++) {
        strcat(buf, " ");
        strcat(buf, tok[i][k]);
    }
}

int main()
{
    FILE *fp = fopen("tac.txt", "r");
    char line[100], before[100], *w, x[20], y[20];
    int count = 0;

    if (fp == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, fp)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        strcpy(line, code[n]);
        nt[n] = 0;
        for (w = strtok(line, " "); w != NULL; w = strtok(NULL, " "))
            strcpy(tok[n][nt[n]++], w);
        n++;
    }
    fclose(fp);

    printf("d) CODE OPTIMISATION - CONSTANT PROPAGATION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nConstants propagated:\n");
    for (int i = 0; i < n; i++) {
        /* statement  x = constant */
        if (del[i] || nt[i] != 3 || strcmp(tok[i][1], "=") != 0 || !isdigit(tok[i][2][0]))
            continue;
        strcpy(x, tok[i][0]);
        strcpy(y, tok[i][2]);

        for (int k = i + 1; k < n && nt[k] != 1; k++) {
            if (del[k])
                continue;
            join(k, before);
            if (replace(k, x, y)) {
                join(k, line);
                printf("%-15s  =>  %-15s (using %s = %s)\n", before, line, x, y);
                count++;
            }
            /* stop when x gets a new value, or block ends */
            if (strcmp(defined(k), x) == 0 || boundary(k))
                break;
        }

        /* temp not needed any more */
        if (istemp(x) && !used(x)) {
            printf("%-15s  =>  removed (%s not used any more)\n", code[i], x);
            del[i] = 1;
        }
    }
    if (count == 0)
        printf("None\n");

    fp = fopen("optimized.txt", "w");
    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++) {
        if (del[i])
            continue;
        join(i, line);
        fprintf(fp, "%s\n", line);
        printf("%s\n", line);
    }
    fclose(fp);

    return 0;
}
