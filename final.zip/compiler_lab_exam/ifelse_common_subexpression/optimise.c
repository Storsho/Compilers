/* (d) Code optimisation - Common subexpression elimination
   If an expression "a op b" was already computed in the same block
   and a, b are not changed after that, the old result is reused.
       t1 = x * y              t1 = x * y
       ...            =>       ...
       t3 = x * y              (removed, t3 replaced by t1)
       t4 = t3 - z             t4 = t1 - z
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

char tok[100][7][20];   /* each TAC line split into words */
int  nt[100];           /* number of words in the line */
int  del[100];          /* 1 = statement removed */
char code[100][100];
int  n = 0;

int istemp(char *s) { return s[0] == 't' && isdigit(s[1]); }

/* label, goto and if end a basic block */
int boundary(int i)
{
    return nt[i] == 1 || strcmp(tok[i][0], "goto") == 0 || strcmp(tok[i][0], "if") == 0;
}

/* variable assigned by line i, or "" */
char *defined(int i)
{
    if ((nt[i] == 3 || nt[i] == 5) && strcmp(tok[i][1], "=") == 0)
        return tok[i][0];
    return "";
}

void join(int i, char *buf)
{
    strcpy(buf, tok[i][0]);
    for (int k = 1; k < nt[i]; k++) {
        strcat(buf, " ");
        strcat(buf, tok[i][k]);
    }
}

/* same expression ?  (a + b and b + a are same for + and *) */
int same(int i, int j)
{
    if (strcmp(tok[i][3], tok[j][3]) != 0)
        return 0;
    if (strcmp(tok[i][2], tok[j][2]) == 0 && strcmp(tok[i][4], tok[j][4]) == 0)
        return 1;
    if ((strcmp(tok[i][3], "+") == 0 || strcmp(tok[i][3], "*") == 0) &&
        strcmp(tok[i][2], tok[j][4]) == 0 && strcmp(tok[i][4], tok[j][2]) == 0)
        return 1;
    return 0;
}

int main()
{
    FILE *fp = fopen("tac.txt", "r");
    char line[100], *w;
    int count = 0;

    if (fp == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, fp)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        strcpy(line, code[n]);
        nt[n] = 0;
        for (w = strtok(line, " "); w != NULL; w = strtok(NULL, " "))
            strcpy(tok[n][nt[n]++], w);
        n++;
    }
    fclose(fp);

    printf("d) CODE OPTIMISATION - COMMON SUBEXPRESSION ELIMINATION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nCommon subexpressions found:\n");
    for (int i = 0; i < n; i++) {
        if (nt[i] != 5 || !istemp(tok[i][0]))
            continue;

        /* search backwards in the same block for the same expression */
        for (int j = i - 1; j >= 0 && !boundary(j); j--) {
            if (del[j] || nt[j] != 5 || !istemp(tok[j][0]) || !same(i, j))
                continue;

            /* operands must not change between j and i */
            int ok = 1;
            for (int k = j; k < i; k++)
                if (!del[k] && (strcmp(defined(k), tok[i][2]) == 0 ||
                                strcmp(defined(k), tok[i][4]) == 0))
                    ok = 0;
            if (!ok)
                break;

            /* reuse result of line j : remove line i and
               replace its temp everywhere after it */
            printf("%-15s  =>  removed, %s replaced by %s\n", code[i], tok[i][0], tok[j][0]);
            del[i] = 1;
            for (int k = i + 1; k < n; k++)
                for (int m = 1; m < nt[k]; m++)
                    if (strcmp(tok[k][m], tok[i][0]) == 0)
                        strcpy(tok[k][m], tok[j][0]);
            count++;
            break;
        }
    }
    if (count == 0)
        printf("None\n");

    fp = fopen("optimized.txt", "w");
    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++) {
        if (del[i])
            continue;
        join(i, line);
        fprintf(fp, "%s\n", line);
        printf("%s\n", line);
    }
    fclose(fp);

    return 0;
}
