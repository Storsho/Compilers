if (a > b)
{
    c = x * y + z;
    d = x * y - z;
}
else
{
    e = p + q;
    f = p + q + r;
}
