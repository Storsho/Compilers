%{
/* (b) YACC specification - syntax checking
   (c) SDT - generates three address code into tac.txt
   Grammar for assignment, if and if-else statements */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex();
void yyerror(const char *s);
extern int yylineno;

FILE *fp;
int tempno = 0, labelno = 0;

/* label stack (to allow nesting)
   lab1 = true part, lab2 = else part, lab3 = end of if-else */
int top = -1;
int lab1[20], lab2[20], lab3[20];

char *newtemp()
{
    char buf[10];
    sprintf(buf, "t%d", ++tempno);
    return strdup(buf);
}
%}

%union {
    char *str;
}

%token IF ELSE
%token <str> ID NUM RELOP
%type  <str> expr

%left '+' '-'
%left '*' '/'

%%
program   : stmt_list
          ;

stmt_list : stmt_list stmt
          |
          ;

stmt      : assign
          | if_stmt
          ;

block     : '{' stmt_list '}'
          ;

assign    : ID '=' expr ';'
            { fprintf(fp, "%s = %s\n", $1, $3); }
          ;

cond     : expr RELOP expr
            {
                fprintf(fp, "if %s %s %s goto L%d\n", $1, $2, $3, lab1[top]);
                fprintf(fp, "goto L%d\n", lab2[top]);
                fprintf(fp, "L%d:\n", lab1[top]);
            }
          ;

/* ---------- if and if-else ---------- */
if_head   : IF '('
            {
                top++;
                lab1[top] = ++labelno;
                lab2[top] = ++labelno;
            }
            cond ')'
          ;

if_stmt   : if_head block
            {
                fprintf(fp, "L%d:\n", lab2[top]);
                top--;
            }
          | if_head block ELSE
            {
                lab3[top] = ++labelno;
                fprintf(fp, "goto L%d\n", lab3[top]);
                fprintf(fp, "L%d:\n", lab2[top]);
            }
            block
            {
                fprintf(fp, "L%d:\n", lab3[top]);
                top--;
            }
          ;

expr      : expr '+' expr { $$ = newtemp(); fprintf(fp, "%s = %s + %s\n", $$, $1, $3); }
          | expr '-' expr { $$ = newtemp(); fprintf(fp, "%s = %s - %s\n", $$, $1, $3); }
          | expr '*' expr { $$ = newtemp(); fprintf(fp, "%s = %s * %s\n", $$, $1, $3); }
          | expr '/' expr { $$ = newtemp(); fprintf(fp, "%s = %s / %s\n", $$, $1, $3); }
          | '(' expr ')'  { $$ = $2; }
          | ID            { $$ = $1; }
          | NUM           { $$ = $1; }
          ;
%%

void yyerror(const char *s)
{
    printf("\nSyntax error at line %d : %s\n", yylineno, s);
}

int main()
{
    char line[100];

    fp = fopen("tac.txt", "w");

    printf("a) LEXICAL ANALYSIS - TOKENS\n");
    printf("%-10s %s\n", "LEXEME", "TOKEN");
    printf("------------------------------\n");

    if (yyparse() != 0) {
        fclose(fp);
        printf("\nb) SYNTAX ANALYSIS\n");
        printf("Input program is NOT syntactically correct\n");
        return 1;
    }
    fclose(fp);

    printf("\nb) SYNTAX ANALYSIS\n");
    printf("Input program is syntactically correct\n");

    printf("\nc) THREE ADDRESS CODE (saved in tac.txt)\n");
    fp = fopen("tac.txt", "r");
    while (fgets(line, sizeof(line), fp))
        printf("%s", line);
    fclose(fp);

    return 0;
}
