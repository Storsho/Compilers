/* (d) Code optimisation - Dead code elimination
   A statement is dead (removed) when
     1. the variable it assigns is assigned again in the same block
        before anyone uses it, e.g.  a = t1 ... a = t2   (a = t1 is dead)
     2. it assigns a temporary that is never used anywhere.
   Removing one dead statement can make another one dead, so the
   checks are repeated until nothing changes.
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

char tok[100][7][20];   /* each TAC line split into words */
int  nt[100];           /* number of words in the line */
int  del[100];          /* 1 = statement removed */
char code[100][100];
int  n = 0;

int istemp(char *s) { return s[0] == 't' && isdigit(s[1]); }

/* label, goto and if end a basic block */
int boundary(int i)
{
    return nt[i] == 1 || strcmp(tok[i][0], "goto") == 0 || strcmp(tok[i][0], "if") == 0;
}

/* variable assigned by line i, or "" */
char *defined(int i)
{
    if ((nt[i] == 3 || nt[i] == 5) && strcmp(tok[i][1], "=") == 0)
        return tok[i][0];
    return "";
}

/* does line i read the value of variable s ? */
int uses(int i, char *s)
{
    if (strcmp(tok[i][0], "if") == 0)
        return strcmp(tok[i][1], s) == 0 || strcmp(tok[i][3], s) == 0;
    if (nt[i] == 3)
        return strcmp(tok[i][2], s) == 0;
    if (nt[i] == 5)
        return strcmp(tok[i][2], s) == 0 || strcmp(tok[i][4], s) == 0;
    return 0;
}

void join(int i, char *buf)
{
    strcpy(buf, tok[i][0]);
    for (int k = 1; k < nt[i]; k++) {
        strcat(buf, " ");
        strcat(buf, tok[i][k]);
    }
}

int main()
{
    FILE *fp = fopen("tac.txt", "r");
    char line[100], *w, *x;
    int count = 0, changed = 1;

    if (fp == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, fp)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        strcpy(line, code[n]);
        nt[n] = 0;
        for (w = strtok(line, " "); w != NULL; w = strtok(NULL, " "))
            strcpy(tok[n][nt[n]++], w);
        n++;
    }
    fclose(fp);

    printf("d) CODE OPTIMISATION - DEAD CODE ELIMINATION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nDead statements removed:\n");
    while (changed) {
        changed = 0;
        for (int i = 0; i < n; i++) {
            x = defined(i);
            if (del[i] || strlen(x) == 0)
                continue;

            /* rule 1 : assigned again before use in the same block */
            int dead = 0;
            for (int k = i + 1; k < n; k++) {
                if (del[k])
                    continue;
                if (uses(k, x))
                    break;
                if (strcmp(defined(k), x) == 0) {
                    dead = 1;
                    break;
                }
                if (boundary(k))
                    break;
            }
            if (dead) {
                printf("%-15s  (%s is assigned again before it is used)\n", code[i], x);
                del[i] = changed = 1;
                count++;
                continue;
            }

            /* rule 2 : temporary which is never used */
            if (istemp(x)) {
                int used = 0;
                for (int k = 0; k < n; k++)
                    if (!del[k] && uses(k, x))
                        used = 1;
                if (!used) {
                    printf("%-15s  (%s is never used)\n", code[i], x);
                    del[i] = changed = 1;
                    count++;
                }
            }
        }
    }
    if (count == 0)
        printf("None\n");

    fp = fopen("optimized.txt", "w");
    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++) {
        if (del[i])
            continue;
        join(i, line);
        fprintf(fp, "%s\n", line);
        printf("%s\n", line);
    }
    fclose(fp);

    return 0;
}
