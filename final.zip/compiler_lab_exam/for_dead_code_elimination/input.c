for (i = 0; i < n; i++)
{
    a = x + y;
    a = x - y;
    s = s + a;
}
