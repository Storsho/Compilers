while (i < n)
{
    a = i * 2;
    b = j * 8;
    c = k / 4;
    i = i + 1;
}
