/* (d) Code optimisation - Strength reduction
   Replaces costly operations with cheaper ones:
       x * 2      ->  x + x
       x * 2^k    ->  x << k
       x / 2^k    ->  x >> k
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* returns k if num is 2^k (k >= 1), else 0 */
int power_of_two(char *s)
{
    if (!isdigit(s[0]))
        return 0;
    int num = atoi(s), k = 0;
    if (num < 2)
        return 0;
    while (num % 2 == 0) {
        num = num / 2;
        k++;
    }
    return (num == 1) ? k : 0;
}

int main()
{
    FILE *in = fopen("tac.txt", "r");
    FILE *out;
    char code[100][100], newcode[100][100];
    char res[20], a[20], op[5], b[20], tmp[20];
    int n = 0, k, count = 0;

    if (in == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, in)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        n++;
    }
    fclose(in);

    printf("d) CODE OPTIMISATION - STRENGTH REDUCTION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nReplaced statements:\n");
    for (int i = 0; i < n; i++) {
        strcpy(newcode[i], code[i]);

        if (sscanf(code[i], "%s = %s %s %s", res, a, op, b) != 4)
            continue;

        /* 8 * j is same as j * 8 */
        if (strcmp(op, "*") == 0 && power_of_two(a) && !power_of_two(b)) {
            strcpy(tmp, a);
            strcpy(a, b);
            strcpy(b, tmp);
        }

        k = power_of_two(b);
        if (k == 0)
            continue;

        if (strcmp(op, "*") == 0 && k == 1)
            sprintf(newcode[i], "%s = %s + %s", res, a, a);
        else if (strcmp(op, "*") == 0)
            sprintf(newcode[i], "%s = %s << %d", res, a, k);
        else if (strcmp(op, "/") == 0)
            sprintf(newcode[i], "%s = %s >> %d", res, a, k);
        else
            continue;

        printf("%-15s  =>  %s\n", code[i], newcode[i]);
        count++;
    }
    if (count == 0)
        printf("None\n");

    out = fopen("optimized.txt", "w");
    for (int i = 0; i < n; i++)
        fprintf(out, "%s\n", newcode[i]);
    fclose(out);

    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", newcode[i]);

    return 0;
}
