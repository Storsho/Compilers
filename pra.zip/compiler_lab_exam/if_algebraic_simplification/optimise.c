/* (d) Code optimisation - Algebraic simplification
   Removes useless arithmetic using algebraic identities:
       x + 0 = x     0 + x = x     x - 0 = x
       x * 1 = x     1 * x = x     x / 1 = x
       x * 0 = 0     0 * x = 0
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>

int main()
{
    FILE *in = fopen("tac.txt", "r");
    FILE *out;
    char code[100][100], newcode[100][100];
    char res[20], a[20], op[5], b[20], var[20], t[20];
    int n = 0, m = 0, count = 0;
    int skip[100] = {0};

    if (in == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, in)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        n++;
    }
    fclose(in);

    printf("d) CODE OPTIMISATION - ALGEBRAIC SIMPLIFICATION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nSimplified statements:\n");
    for (int i = 0; i < n; i++) {
        strcpy(newcode[i], code[i]);

        if (sscanf(code[i], "%s = %s %s %s", res, a, op, b) != 4)
            continue;

        if (strcmp(op, "+") == 0 && strcmp(b, "0") == 0)
            sprintf(newcode[i], "%s = %s", res, a);
        else if (strcmp(op, "+") == 0 && strcmp(a, "0") == 0)
            sprintf(newcode[i], "%s = %s", res, b);
        else if (strcmp(op, "-") == 0 && strcmp(b, "0") == 0)
            sprintf(newcode[i], "%s = %s", res, a);
        else if (strcmp(op, "*") == 0 && (strcmp(a, "0") == 0 || strcmp(b, "0") == 0))
            sprintf(newcode[i], "%s = 0", res);
        else if (strcmp(op, "*") == 0 && strcmp(b, "1") == 0)
            sprintf(newcode[i], "%s = %s", res, a);
        else if (strcmp(op, "*") == 0 && strcmp(a, "1") == 0)
            sprintf(newcode[i], "%s = %s", res, b);
        else if (strcmp(op, "/") == 0 && strcmp(b, "1") == 0)
            sprintf(newcode[i], "%s = %s", res, a);
        else
            continue;

        /* the temp now holds a plain value, so "c = t1" can directly
           take that value and the temp statement is not needed */
        if (i + 1 < n && sscanf(code[i + 1], "%s = %s", var, t) == 2 &&
            strcmp(t, res) == 0) {
            sprintf(newcode[i + 1], "%s = %s", var, strchr(newcode[i], '=') + 2);
            skip[i] = 1;
            printf("%s ; %-8s =>  %s\n", code[i], code[i + 1], newcode[i + 1]);
            i++;
        } else {
            printf("%-15s  =>  %s\n", code[i], newcode[i]);
        }
        count++;
    }
    if (count == 0)
        printf("None\n");

    out = fopen("optimized.txt", "w");
    for (int i = 0; i < n; i++)
        if (!skip[i]) {
            fprintf(out, "%s\n", newcode[i]);
            m++;
        }
    fclose(out);

    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++)
        if (!skip[i])
            printf("%s\n", newcode[i]);
    printf("\nStatements reduced from %d to %d\n", n, m);

    return 0;
}
