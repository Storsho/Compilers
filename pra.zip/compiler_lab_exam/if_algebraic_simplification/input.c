if (a > b)
{
    c = a + 0;
    d = b * 1;
    e = c - 0;
    f = d / 1;
    g = a * 0;
    h = c + d;
}
