/* (e) Back end - target code generation
   Reads optimized.txt and converts each statement into
   simple assembly like instructions (written to target.txt) */
#include <stdio.h>
#include <string.h>

int main()
{
    FILE *in = fopen("optimized.txt", "r");
    FILE *out = fopen("target.txt", "w");
    char line[100], res[20], a[20], op[5], b[20], lab[20];

    if (in == NULL) {
        printf("optimized.txt not found. Run the optimiser first.\n");
        return 1;
    }

    while (fgets(line, 100, in)) {
        line[strcspn(line, "\n")] = '\0';
        if (strlen(line) == 0)
            continue;

        /* label  ->  L1: */
        if (line[strlen(line) - 1] == ':') {
            fprintf(out, "%s\n", line);
        }
        /* goto L1  ->  JMP L1 */
        else if (sscanf(line, "goto %s", lab) == 1) {
            fprintf(out, "\tJMP %s\n", lab);
        }
        /* if a < b goto L2  ->  compare and conditional jump */
        else if (sscanf(line, "if %s %s %s goto %s", a, op, b, lab) == 4) {
            fprintf(out, "\tLOAD R1, %s\n", a);
            fprintf(out, "\tCMP R1, %s\n", b);
            if      (strcmp(op, "<")  == 0) fprintf(out, "\tJLT %s\n", lab);
            else if (strcmp(op, "<=") == 0) fprintf(out, "\tJLE %s\n", lab);
            else if (strcmp(op, ">")  == 0) fprintf(out, "\tJGT %s\n", lab);
            else if (strcmp(op, ">=") == 0) fprintf(out, "\tJGE %s\n", lab);
            else if (strcmp(op, "==") == 0) fprintf(out, "\tJEQ %s\n", lab);
            else                            fprintf(out, "\tJNE %s\n", lab);
        }
        /* x = a op b */
        else if (sscanf(line, "%s = %s %s %s", res, a, op, b) == 4) {
            fprintf(out, "\tLOAD R1, %s\n", a);
            if      (strcmp(op, "+") == 0) fprintf(out, "\tADD R1, %s\n", b);
            else if (strcmp(op, "-") == 0) fprintf(out, "\tSUB R1, %s\n", b);
            else if (strcmp(op, "*") == 0) fprintf(out, "\tMUL R1, %s\n", b);
            else if (strcmp(op, "/") == 0) fprintf(out, "\tDIV R1, %s\n", b);
            fprintf(out, "\tSTORE %s, R1\n", res);
        }
        /* x = a */
        else if (sscanf(line, "%s = %s", res, a) == 2) {
            fprintf(out, "\tLOAD R1, %s\n", a);
            fprintf(out, "\tSTORE %s, R1\n", res);
        }
    }
    fclose(in);
    fclose(out);

    printf("e) TARGET CODE (saved in target.txt)\n");
    out = fopen("target.txt", "r");
    while (fgets(line, 100, out))
        printf("%s", line);
    fclose(out);

    return 0;
}
