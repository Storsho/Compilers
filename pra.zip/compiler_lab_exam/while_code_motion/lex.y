%{
/* (b) YACC specification - syntax checking
   (c) SDT - generates three address code into tac.txt */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex();
void yyerror(const char *s);
extern int yylineno;

FILE *fp;
int tempno = 0, labelno = 0;

/* label stack for while loops (to allow nesting) */
int top = -1;
int lstart[20], lbody[20], lend[20];

char *newtemp()
{
    char buf[10];
    sprintf(buf, "t%d", ++tempno);
    return strdup(buf);
}
%}

%union {
    char *str;
}

%token WHILE
%token <str> ID NUM RELOP
%type  <str> expr

%left '+' '-'
%left '*' '/'

%%
program   : stmt_list
          ;

stmt_list : stmt_list stmt
          |
          ;

stmt      : assign
          | while_stmt
          ;

assign    : ID '=' expr ';'
            { fprintf(fp, "%s = %s\n", $1, $3); }
          ;

while_stmt: WHILE '('
            {
                top++;
                lstart[top] = ++labelno;
                lbody[top]  = ++labelno;
                lend[top]   = ++labelno;
                fprintf(fp, "L%d:\n", lstart[top]);
            }
            expr RELOP expr ')'
            {
                fprintf(fp, "if %s %s %s goto L%d\n", $4, $5, $6, lbody[top]);
                fprintf(fp, "goto L%d\n", lend[top]);
                fprintf(fp, "L%d:\n", lbody[top]);
            }
            '{' stmt_list '}'
            {
                fprintf(fp, "goto L%d\n", lstart[top]);
                fprintf(fp, "L%d:\n", lend[top]);
                top--;
            }
          ;

expr      : expr '+' expr { $$ = newtemp(); fprintf(fp, "%s = %s + %s\n", $$, $1, $3); }
          | expr '-' expr { $$ = newtemp(); fprintf(fp, "%s = %s - %s\n", $$, $1, $3); }
          | expr '*' expr { $$ = newtemp(); fprintf(fp, "%s = %s * %s\n", $$, $1, $3); }
          | expr '/' expr { $$ = newtemp(); fprintf(fp, "%s = %s / %s\n", $$, $1, $3); }
          | '(' expr ')'  { $$ = $2; }
          | ID            { $$ = $1; }
          | NUM           { $$ = $1; }
          ;
%%

void yyerror(const char *s)
{
    printf("\nSyntax error at line %d : %s\n", yylineno, s);
}

int main()
{
    char line[100];

    fp = fopen("tac.txt", "w");

    printf("a) LEXICAL ANALYSIS - TOKENS\n");
    printf("%-10s %s\n", "LEXEME", "TOKEN");
    printf("------------------------------\n");

    if (yyparse() != 0) {
        fclose(fp);
        printf("\nb) SYNTAX ANALYSIS\n");
        printf("Input program is NOT syntactically correct\n");
        return 1;
    }
    fclose(fp);

    printf("\nb) SYNTAX ANALYSIS\n");
    printf("Input program is syntactically correct\n");

    printf("\nc) THREE ADDRESS CODE (saved in tac.txt)\n");
    fp = fopen("tac.txt", "r");
    while (fgets(line, sizeof(line), fp))
        printf("%s", line);
    fclose(fp);

    return 0;
}
