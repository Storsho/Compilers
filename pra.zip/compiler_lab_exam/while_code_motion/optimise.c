/* (d) Code optimisation - Loop invariant code motion
   Reads tac.txt, moves loop invariant statements above the loop
   and writes the result into optimized.txt */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

char code[100][100];
char res[100][20], arg1[100][20], op[100][5], arg2[100][20];
int isbin[100], moved[100];
int n = 0;
int lstart = -1, lend = -1;

int istemp(char *s)  { return s[0] == 't' && isdigit(s[1]); }
int isconst(char *s) { return isdigit(s[0]); }

/* is variable s assigned anywhere inside the loop? */
int modified(char *s)
{
    char lhs[20];
    for (int i = lstart + 1; i < lend; i++)
        if (strstr(code[i], " = ") && sscanf(code[i], "%s", lhs) == 1 && strcmp(lhs, s) == 0)
            return 1;
    return 0;
}

/* is temp s already marked as moved out of the loop? */
int hoisted(char *s)
{
    for (int i = lstart + 1; i < lend; i++)
        if (moved[i] && strcmp(res[i], s) == 0)
            return 1;
    return 0;
}

/* operand does not change inside the loop */
int invariant(char *s)
{
    if (isconst(s)) return 1;
    if (istemp(s))  return hoisted(s);
    return !modified(s);
}

int main()
{
    FILE *fp = fopen("tac.txt", "r");
    char lab[20];

    if (fp == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, fp)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        isbin[n] = (sscanf(code[n], "%s = %s %s %s", res[n], arg1[n], op[n], arg2[n]) == 4);
        n++;
    }
    fclose(fp);

    /* find the loop : "goto Lx" whose label Lx: appears before it */
    for (int i = 0; i < n && lstart == -1; i++) {
        if (sscanf(code[i], "goto %s", lab) == 1) {
            strcat(lab, ":");
            for (int j = 0; j < i; j++)
                if (strcmp(code[j], lab) == 0) {
                    lstart = j;
                    lend = i;
                    break;
                }
        }
    }

    printf("d) CODE OPTIMISATION - LOOP INVARIANT CODE MOTION\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    if (lstart == -1) {
        printf("\nNo loop found, code is unchanged.\n");
    } else {
        /* keep marking statements until nothing new is found,
           so that t4 = t3 + z is moved once t3 is moved */
        int changed = 1;
        while (changed) {
            changed = 0;
            for (int i = lstart + 1; i < lend; i++) {
                if (isbin[i] && !moved[i] && istemp(res[i]) &&
                    invariant(arg1[i]) && invariant(arg2[i])) {
                    moved[i] = 1;
                    changed = 1;
                }
            }
        }

        printf("\nLoop invariant statements moved before the loop:\n");
        for (int i = 0; i < n; i++)
            if (moved[i])
                printf("%s\n", code[i]);
    }

    /* write optimised code */
    fp = fopen("optimized.txt", "w");
    for (int i = 0; i < lstart; i++)
        fprintf(fp, "%s\n", code[i]);
    for (int i = 0; i < n; i++)
        if (moved[i])
            fprintf(fp, "%s\n", code[i]);
    for (int i = (lstart == -1 ? 0 : lstart); i < n; i++)
        if (!moved[i])
            fprintf(fp, "%s\n", code[i]);
    fclose(fp);

    printf("\nAfter optimisation (saved in optimized.txt):\n");
    fp = fopen("optimized.txt", "r");
    char line[100];
    while (fgets(line, 100, fp))
        printf("%s", line);
    fclose(fp);

    return 0;
}
