/* (d) Code optimisation - Constant folding
   If both operands of an operation are constants, the result is
   calculated at compile time.  e.g.  t1 = 10 + 20  ->  t1 = 30
   A temporary that gets folded is replaced by its value in the
   same expression.  Named variables (a, b, ...) are not replaced.
   Reads tac.txt and writes optimized.txt */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char tname[100][20];   /* folded temporaries and their values */
int  tval[100];
int  tcount = 0;

int isconst(char *s) { return isdigit(s[0]); }
int istemp(char *s)  { return s[0] == 't' && isdigit(s[1]); }

/* if s is a folded temp, replace it with its value */
void replace(char *s)
{
    if (!istemp(s))
        return;
    for (int i = 0; i < tcount; i++)
        if (strcmp(tname[i], s) == 0) {
            sprintf(s, "%d", tval[i]);
            return;
        }
}

int main()
{
    FILE *in = fopen("tac.txt", "r");
    FILE *out;
    char code[100][100], newcode[100][100];
    char res[20], a[20], op[5], b[20];
    int n = 0, x, y, val, count = 0;

    if (in == NULL) {
        printf("tac.txt not found. Run the compiler first.\n");
        return 1;
    }
    while (fgets(code[n], 100, in)) {
        code[n][strcspn(code[n], "\n")] = '\0';
        n++;
    }
    fclose(in);

    printf("d) CODE OPTIMISATION - CONSTANT FOLDING\n");
    printf("\nBefore optimisation:\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", code[i]);

    printf("\nFolded statements:\n");
    for (int i = 0; i < n; i++) {
        strcpy(newcode[i], code[i]);

        if (sscanf(code[i], "%s = %s %s %s", res, a, op, b) != 4)
            continue;

        replace(a);
        replace(b);

        if (isconst(a) && isconst(b)) {
            x = atoi(a);
            y = atoi(b);
            if      (strcmp(op, "+") == 0) val = x + y;
            else if (strcmp(op, "-") == 0) val = x - y;
            else if (strcmp(op, "*") == 0) val = x * y;
            else if (strcmp(op, "/") == 0 && y != 0) val = x / y;
            else continue;          /* division by zero - leave it */

            sprintf(newcode[i], "%s = %d", res, val);
            if (istemp(res)) {
                strcpy(tname[tcount], res);
                tval[tcount++] = val;
            }
        } else {
            sprintf(newcode[i], "%s = %s %s %s", res, a, op, b);
        }

        if (strcmp(newcode[i], code[i]) != 0) {
            printf("%-15s  =>  %s\n", code[i], newcode[i]);
            count++;
        }
    }
    if (count == 0)
        printf("None\n");

    out = fopen("optimized.txt", "w");
    for (int i = 0; i < n; i++)
        fprintf(out, "%s\n", newcode[i]);
    fclose(out);

    printf("\nAfter optimisation (saved in optimized.txt):\n");
    for (int i = 0; i < n; i++)
        printf("%s\n", newcode[i]);

    return 0;
}
