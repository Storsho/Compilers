/* (e) Back end - target code generation
   Reads optimized.txt and converts each statement into
   simple assembly like instructions (written to target.txt) */
#include <stdio.h>
#include <string.h>

int main()
{
    FILE *in = fopen("optimized.txt", "r");
    FILE *out = fopen("target.txt", "w");
    char line[100], res[20], a[20], op[5], b[20];

    if (in == NULL) {
        printf("optimized.txt not found. Run the optimiser first.\n");
        return 1;
    }

    while (fgets(line, 100, in)) {
        line[strcspn(line, "\n")] = '\0';
        if (strlen(line) == 0)
            continue;

        /* x = a op b */
        if (sscanf(line, "%s = %s %s %s", res, a, op, b) == 4) {
            fprintf(out, "\tLOAD R1, %s\n", a);
            if      (strcmp(op, "+") == 0) fprintf(out, "\tADD R1, %s\n", b);
            else if (strcmp(op, "-") == 0) fprintf(out, "\tSUB R1, %s\n", b);
            else if (strcmp(op, "*") == 0) fprintf(out, "\tMUL R1, %s\n", b);
            else if (strcmp(op, "/") == 0) fprintf(out, "\tDIV R1, %s\n", b);
            fprintf(out, "\tSTORE %s, R1\n", res);
        }
        /* x = a */
        else if (sscanf(line, "%s = %s", res, a) == 2) {
            fprintf(out, "\tLOAD R1, %s\n", a);
            fprintf(out, "\tSTORE %s, R1\n", res);
        }
    }
    fclose(in);
    fclose(out);

    printf("e) TARGET CODE (saved in target.txt)\n");
    out = fopen("target.txt", "r");
    while (fgets(line, 100, out))
        printf("%s", line);
    fclose(out);

    return 0;
}
