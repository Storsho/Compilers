%{
/* (b) YACC specification - syntax checking
   (c) SDT - generates three address code into tac.txt */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex();
void yyerror(const char *s);
extern int yylineno;

FILE *fp;
int tempno = 0;

char *newtemp()
{
    char buf[10];
    sprintf(buf, "t%d", ++tempno);
    return strdup(buf);
}
%}

%union {
    char *str;
}

%token <str> ID NUM
%type  <str> expr

%left '+' '-'
%left '*' '/'

%%
program   : stmt_list
          ;

stmt_list : stmt_list assign
          |
          ;

assign    : ID '=' expr ';'
            { fprintf(fp, "%s = %s\n", $1, $3); }
          ;

expr      : expr '+' expr { $$ = newtemp(); fprintf(fp, "%s = %s + %s\n", $$, $1, $3); }
          | expr '-' expr { $$ = newtemp(); fprintf(fp, "%s = %s - %s\n", $$, $1, $3); }
          | expr '*' expr { $$ = newtemp(); fprintf(fp, "%s = %s * %s\n", $$, $1, $3); }
          | expr '/' expr { $$ = newtemp(); fprintf(fp, "%s = %s / %s\n", $$, $1, $3); }
          | '(' expr ')'  { $$ = $2; }
          | ID            { $$ = $1; }
          | NUM           { $$ = $1; }
          ;
%%

void yyerror(const char *s)
{
    printf("\nSyntax error at line %d : %s\n", yylineno, s);
}

int main()
{
    char line[100];

    fp = fopen("tac.txt", "w");

    printf("a) LEXICAL ANALYSIS - TOKENS\n");
    printf("%-10s %s\n", "LEXEME", "TOKEN");
    printf("------------------------------\n");

    if (yyparse() != 0) {
        fclose(fp);
        printf("\nb) SYNTAX ANALYSIS\n");
        printf("Input program is NOT syntactically correct\n");
        return 1;
    }
    fclose(fp);

    printf("\nb) SYNTAX ANALYSIS\n");
    printf("Input program is syntactically correct\n");

    printf("\nc) THREE ADDRESS CODE (saved in tac.txt)\n");
    fp = fopen("tac.txt", "r");
    while (fgets(line, sizeof(line), fp))
        printf("%s", line);
    fclose(fp);

    return 0;
}
